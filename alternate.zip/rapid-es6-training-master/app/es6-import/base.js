//Import Aliases
//import { projectId as id, projectName } from 'module1.js'

//Import Default as alias
//import { default as myProjectName } from 'module1.js'

//Import SomeValue as default Alias
//import someValue from 'module1.js'

//Import All
import * as values from './import.js'

//Print Console
//console.log(`${projectName} has id: ${id}`);
console.log(values);